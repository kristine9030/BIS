package barangayinformationsystem;

public class BarangayInformationSystem {
  
    public static void main(String[] args) {
        Home HomeFrame = new Home();
        HomeFrame.setVisible(true);
        HomeFrame.pack();
        HomeFrame.setLocationRelativeTo(null); 
    }
    
}
